"""
Top Recommendation Engine.

Filters, ranks, sorts, and deduplicates recommendations down to a
final top-N list, returned as the boundary-facing RankedStock model.
"""

from __future__ import annotations

from typing import Any

from app.top10.models import RankedStock
from app.top10.ranking_engine import RankingEngine

_ACTIONABLE_DECISIONS = ("STRONG BUY", "BUY", "WATCH")


class Top10Engine:

    def __init__(self) -> None:
        self.ranker = RankingEngine()

    def generate(
        self,
        recommendations: list[Any],
        limit: int = 10,
        sort_by: str = "Confidence",
    ) -> list[RankedStock]:
        if not recommendations:
            return []

        actionable = [
            r for r in recommendations if r.recommendation in _ACTIONABLE_DECISIONS
        ]
        if not actionable:
            return []

        ranked = self.ranker.rank(actionable)

        sort_key = sort_by.lower()
        if sort_key == "score":
            ranked.sort(key=lambda r: r.scores.get("technical", 0), reverse=True)
        elif sort_key == "probability":
            ranked.sort(key=lambda r: r.probability, reverse=True)
        elif sort_key == "price":
            ranked.sort(key=lambda r: r.entry)
        else:
            ranked.sort(key=lambda r: r.confidence, reverse=True)

        final: list[RankedStock] = []
        seen: set[str] = set()

        for recommendation in ranked:
            if recommendation.symbol in seen:
                continue
            seen.add(recommendation.symbol)
            final.append(RankedStock.from_recommendation(recommendation))
            if len(final) >= limit:
                break

        return final