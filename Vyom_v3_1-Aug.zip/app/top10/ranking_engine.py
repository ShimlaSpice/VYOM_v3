"""
Top 10 Ranking Engine.

Ranks Recommendation-shaped objects (must expose .confidence, .scores
dict, and .symbol) — this runs before Top10Engine converts the result
down to the smaller RankedStock output model.
"""

from __future__ import annotations

from typing import Any


class RankingEngine:

    def rank(self, recommendations: list[Any]) -> list[Any]:
        return sorted(
            recommendations,
            key=lambda recommendation: (
                recommendation.confidence,
                recommendation.scores.get("technical", 0),
                recommendation.scores.get("fundamental", 0),
                recommendation.scores.get("news", 0),
                recommendation.scores.get("sector", 0),
                recommendation.scores.get("risk", 0),
                recommendation.symbol,
            ),
            reverse=True,
        )