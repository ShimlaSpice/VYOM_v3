"""
Provider Manager for VYOM.

Delegates to an active MarketDataProvider, with a small per-symbol
MarketContext cache so repeated scans in one session don't refetch.
Fixes a previously broken import (app.market.providers.yahoo_provider,
a path that doesn't exist) and drops delegation for the satellite
methods removed from MarketDataProvider — use the dedicated satellite
provider classes directly for those.
"""

from __future__ import annotations

from typing import Any

from app.market.market_data_provider import MarketDataProvider
from app.market.yahoo_provider import YahooFinanceProvider
from core.market_context import MarketContext


class ProviderManager(MarketDataProvider):

    def __init__(self) -> None:
        self.providers: list[MarketDataProvider] = [YahooFinanceProvider()]
        self.active_provider = self.providers[0]
        self._contexts: dict[str, MarketContext] = {}

    def connect(self) -> None:
        self.active_provider.connect()

    def disconnect(self) -> None:
        self.active_provider.disconnect()

    def prefetch(
        self,
        symbols: list[str],
        period: str = "3mo",
        interval: str = "1d",
    ) -> None:
        self.active_provider.prefetch(symbols, period, interval)

    def get_market_context(self, symbol: str) -> MarketContext | None:
        if symbol not in self._contexts:
            context = self.active_provider.get_market_context(symbol)
            if context is None:
                return None
            self._contexts[symbol] = context
        return self._contexts[symbol]

    def clear_context_cache(self) -> None:
        self._contexts.clear()

    def get_quote(self, symbol: str) -> dict[str, Any]:
        return self.active_provider.get_quote(symbol)

    def get_bulk_quotes(self, symbols: list[str]) -> dict[str, Any]:
        return self.active_provider.get_bulk_quotes(symbols)

    def get_candles(
        self, symbol: str, interval: str, limit: int = 100,
    ) -> list[dict[str, Any]]:
        return self.active_provider.get_candles(symbol, interval, limit)

    def get_fundamentals(self, symbol: str) -> dict[str, Any]:
        return self.active_provider.get_fundamentals(symbol)

    def get_news(self, symbol: str) -> dict[str, Any]:
        return self.active_provider.get_news(symbol)

    def get_watchlist(self, universe: str = "nifty50") -> list[str]:
        return self.active_provider.get_watchlist(universe)

    def get_market_status(self) -> dict[str, Any]:
        return self.active_provider.get_market_status()