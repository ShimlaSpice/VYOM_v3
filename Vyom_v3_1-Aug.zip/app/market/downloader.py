"""
Batch Downloader for VYOM.

Downloads historical candles for multiple symbols through a provider.
This is the only BatchDownloader in the codebase (a second, unrelated
class of the same name in the now-removed batch_downloader.py has been
deleted — it was dead code, imported nowhere, colliding on name only).
"""

from __future__ import annotations

import time
from typing import Any

from app.market.market_data_provider import MarketDataProvider


class BatchDownloader:
    """Downloads historical data for multiple symbols via a provider."""

    def __init__(self, provider: MarketDataProvider) -> None:
        self.provider = provider

    def download_history(
        self,
        symbols: list[str],
        interval: str = "1d",
        limit: int = 100,
    ) -> dict[str, list[dict[str, Any]]]:
        start = time.perf_counter()
        results: dict[str, list[dict[str, Any]]] = {}
        successful = 0
        failed = 0

        for symbol in symbols:
            try:
                results[symbol] = self.provider.get_candles(
                    symbol=symbol, interval=interval, limit=limit,
                )
                successful += 1
            except Exception:
                results[symbol] = []
                failed += 1

        elapsed = time.perf_counter() - start
        print()
        print("=" * 60)
        print("Batch Download Summary")
        print("=" * 60)
        print(f"Symbols     : {len(symbols)}")
        print(f"Successful  : {successful}")
        print(f"Failed      : {failed}")
        print(f"Time Taken  : {elapsed:.2f} sec")
        print("=" * 60)

        return results