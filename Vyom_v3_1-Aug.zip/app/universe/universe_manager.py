"""
Universe Manager.

Resolves a universe name to its symbol list. Delegates the actual file
reading to WatchlistLoader (app.market) instead of re-implementing the
same "read data/watchlists/X.txt" logic a second time.
"""

from __future__ import annotations

from app.market.watchlist_loader import WatchlistLoader


class UniverseManager:

    def __init__(self) -> None:
        self._loader = WatchlistLoader()

    def get_symbols(self, universe: str) -> list[str]:
        try:
            return self._loader.load(f"{universe.lower()}.txt")
        except FileNotFoundError:
            return []