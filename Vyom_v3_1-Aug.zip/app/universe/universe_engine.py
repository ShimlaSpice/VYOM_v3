"""
Universe Engine.

Provides stock universes for scanning.
"""

from __future__ import annotations

from app.universe.universe_downloader import UniverseDownloader
from app.universe.universe_manager import UniverseManager


class UniverseEngine:

    def __init__(self) -> None:
        self.manager = UniverseManager()

    def get_universe(self, universe: str = "NIFTY50") -> list[str]:
        symbols = self.manager.get_symbols(universe)
        if not symbols:
            raise ValueError(f"No symbols found for universe: {universe}")
        return symbols

    def available_universes(self) -> list[str]:
        """Universes VYOM can actually resolve — derived from
        UniverseDownloader.FILES, the single source of truth for which
        watchlist files can be produced. (Previously this hardcoded a
        second list that included FO/MIDCAP/SMALLCAP/PENNY, none of
        which have a corresponding watchlist file or downloader.)"""
        return sorted(UniverseDownloader.FILES.keys())