"""
Stock Details Panel for VYOM.
"""

from __future__ import annotations

from PySide6.QtWidgets import (
    QFormLayout,
    QGroupBox,
    QLabel,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)


class StockDetails(QWidget):
    """
    Displays complete Jarvis analysis
    for the selected stock.
    """

    def __init__(self) -> None:

        super().__init__()

        self._build_ui()

    def _build_ui(self) -> None:

        self.symbol = QLabel("-")

        self.action = QLabel("-")

        self.rating = QLabel("-")

        self.score = QLabel("-")

        self.confidence = QLabel("-")

        self.entry = QLabel("-")

        self.target = QLabel("-")

        self.stop_loss = QLabel("-")

        self.risk = QLabel("-")

        self.holding = QLabel("-")

        self.capital = QLabel("-")

        self.quantity = QLabel("-")

        self.expected_profit = QLabel("-")

        self.maximum_loss = QLabel("-")

        self.form = QFormLayout()

        self.form.addRow("Symbol", self.symbol)

        self.form.addRow("Recommendation", self.action)

        self.form.addRow("Rating", self.rating)

        self.form.addRow("Score", self.score)

        self.form.addRow("Confidence", self.confidence)

        self.form.addRow("Entry", self.entry)

        self.form.addRow("Target", self.target)

        self.form.addRow("Stop Loss", self.stop_loss)

        self.form.addRow("Risk", self.risk)

        self.form.addRow("Holding", self.holding)

        self.form.addRow("Capital", self.capital)

        self.form.addRow("Quantity", self.quantity)

        self.form.addRow("Expected Profit", self.expected_profit)

        self.form.addRow("Maximum Loss", self.maximum_loss)

        info_group = QGroupBox("Trade Details")

        info_group.setLayout(self.form)

        self.reasons = QTextEdit()

        self.reasons.setReadOnly(True)

        self.reasons.setPlaceholderText(
            "Jarvis reasoning..."
        )

        self.summary = QTextEdit()

        self.summary.setReadOnly(True)

        self.summary.setPlaceholderText(
            "Jarvis summary..."
        )

        layout = QVBoxLayout()

        layout.addWidget(info_group)

        layout.addWidget(
            QLabel("Reasons")
        )

        layout.addWidget(
            self.reasons
        )

        layout.addWidget(
            QLabel("Jarvis Summary")
        )

        layout.addWidget(
            self.summary
        )

        self.setLayout(layout)

    def update_details(

        self,

        stock: dict,

    ) -> None:

        self.symbol.setText(

            str(stock.get("symbol", "-"))

        )

        self.action.setText(

            str(stock.get("action", "-"))

        )

        self.rating.setText(

            str(stock.get("rating", "-"))

        )

        self.score.setText(

            str(stock.get("score", "-"))

        )

        self.confidence.setText(

            str(stock.get("confidence", "-"))

        )

        self.entry.setText(

            str(stock.get("entry", "-"))

        )

        self.target.setText(

            str(stock.get("target", "-"))

        )

        self.stop_loss.setText(

            str(stock.get("stop_loss", "-"))

        )

        self.risk.setText(

            str(stock.get("risk", "-"))

        )

        self.holding.setText(

            str(stock.get("holding", "-"))

        )

        self.capital.setText(

            str(stock.get("capital", "-"))

        )

        self.quantity.setText(

            str(stock.get("quantity", "-"))

        )

        self.expected_profit.setText(

            str(stock.get("expected_profit", "-"))

        )

        self.maximum_loss.setText(

            str(stock.get("maximum_loss", "-"))

        )

        reasons = stock.get(

            "reasons",

            [],

        )

        if isinstance(

            reasons,

            list,

        ):

            self.reasons.setPlainText(

                "\n".join(

                    f"✓ {reason}"

                    for reason in reasons

                )

            )

        else:

            self.reasons.setPlainText(

                str(reasons)

            )

        self.summary.setPlainText(

            str(

                stock.get(

                    "summary",

                    "",

                )

            )

        )