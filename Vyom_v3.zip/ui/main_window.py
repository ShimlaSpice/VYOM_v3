"""
Main Window for VYOM Desktop.
"""

from __future__ import annotations

from PySide6.QtWidgets import (
    QHBoxLayout,
    QMainWindow,
    QVBoxLayout,
    QWidget,
)

from app.ui.dashboard import Dashboard
from app.ui.filter_bar import FilterBar
from app.ui.left_sidebar import LeftSidebar
from app.ui.status_bar import StatusBar
from app.ui.top_bar import TopBar


class MainWindow(QMainWindow):
    """
    Main application window.
    """

    def __init__(self) -> None:

        super().__init__()

        self.setWindowTitle(
            "VYOM AI"
        )

        self.resize(
            1600,
            900,
        )

        self._build_ui()

        self._connect_signals()

    def _build_ui(self) -> None:

        self.top_bar = TopBar()

        self.filter_bar = FilterBar()

        self.sidebar = LeftSidebar()

        self.dashboard = Dashboard()

        self.status = StatusBar()

        central = QWidget()

        self.setCentralWidget(
            central,
        )

        root_layout = QVBoxLayout()

        root_layout.setContentsMargins(
            5,
            5,
            5,
            5,
        )

        root_layout.setSpacing(
            5,
        )

        root_layout.addWidget(
            self.top_bar,
        )

        root_layout.addWidget(
            self.filter_bar,
        )

        body = QHBoxLayout()

        body.setSpacing(
            5,
        )

        body.addWidget(
            self.sidebar,
        )

        body.addWidget(
            self.dashboard,
            1,
        )

        root_layout.addLayout(
            body,
            1,
        )

        root_layout.addWidget(
            self.status,
        )

        central.setLayout(
            root_layout,
        )

    def _connect_signals(self) -> None:

        self.sidebar.category_changed.connect(

            self._category_changed,

        )

        self.filter_bar.scan_requested.connect(

            self._scan_requested,

        )

    def _category_changed(

        self,

        category: str,

    ) -> None:

        self.filter_bar.category.setCurrentText(

            category,

        )

    def _scan_requested(

        self,

        filters: dict,

    ) -> None:

        """
        Sprint 48

        This method will call:

        VyomEngine.run(filters)

        and populate the dashboard.
        """

        print(filters)