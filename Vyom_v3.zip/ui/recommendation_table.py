"""
Recommendation Table for VYOM.
"""

from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QAbstractItemView,
    QHeaderView,
    QTableWidget,
    QTableWidgetItem,
)


class RecommendationTable(QTableWidget):
    """
    Displays Top Recommendations.
    """

    stock_selected = Signal(dict)

    HEADERS = [

        "Rank",

        "Symbol",

        "Market",

        "Price",

        "Score",

        "Confidence",

        "Action",

        "Entry",

        "Target",

        "SL",

    ]

    def __init__(self) -> None:

        super().__init__()

        self._build_ui()

    def _build_ui(self) -> None:

        self.setColumnCount(

            len(self.HEADERS),

        )

        self.setHorizontalHeaderLabels(

            self.HEADERS,

        )

        self.verticalHeader().setVisible(

            False,

        )

        self.setSelectionBehavior(

            QAbstractItemView.SelectRows,

        )

        self.setSelectionMode(

            QAbstractItemView.SingleSelection,

        )

        self.setEditTriggers(

            QAbstractItemView.NoEditTriggers,

        )

        self.setAlternatingRowColors(

            True,

        )

        self.setSortingEnabled(

            True,

        )

        self.horizontalHeader().setSectionResizeMode(

            QHeaderView.Stretch,

        )

        self.itemSelectionChanged.connect(

            self._emit_selected,

        )

    def load_recommendations(

        self,

        recommendations: list[dict],

    ) -> None:

        self.setSortingEnabled(

            False,

        )

        self.setRowCount(

            len(recommendations),

        )

        for row, stock in enumerate(recommendations):

            values = [

                stock.get(

                    "rank",

                    row + 1,

                ),

                stock.get(

                    "symbol",

                    "",

                ),

                stock.get(

                    "market",

                    "NSE",

                ),

                f"₹{stock.get('price', 0):,.2f}",

                stock.get(

                    "score",

                    0,

                ),

                f"{stock.get('confidence', 0)}%",

                stock.get(

                    "action",

                    "WATCH",

                ),

                f"₹{stock.get('entry', 0):,.2f}",

                f"₹{stock.get('target', 0):,.2f}",

                f"₹{stock.get('stop_loss', 0):,.2f}",

            ]

            for column, value in enumerate(values):

                item = QTableWidgetItem(

                    str(value),

                )

                item.setTextAlignment(

                    Qt.AlignCenter,

                )

                self.setItem(

                    row,

                    column,

                    item,

                )

        self.setSortingEnabled(

            True,

        )

    def clear_table(

        self,

    ) -> None:

        self.setRowCount(

            0,

        )

    def _emit_selected(

        self,

    ) -> None:

        row = self.currentRow()

        if row < 0:

            return

        recommendation = {

            "rank": self.item(

                row,

                0,

            ).text(),

            "symbol": self.item(

                row,

                1,

            ).text(),

            "market": self.item(

                row,

                2,

            ).text(),

            "price": self.item(

                row,

                3,

            ).text(),

            "score": self.item(

                row,

                4,

            ).text(),

            "confidence": self.item(

                row,

                5,

            ).text(),

            "action": self.item(

                row,

                6,

            ).text(),

            "entry": self.item(

                row,

                7,

            ).text(),

            "target": self.item(

                row,

                8,

            ).text(),

            "stop_loss": self.item(

                row,

                9,

            ).text(),

        }

        self.stock_selected.emit(

            recommendation,

        )