"""
Filter Bar for VYOM Dashboard.
"""

from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QComboBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QWidget,
)


class FilterBar(QWidget):
    """
    Dashboard filter bar.
    """

    scan_requested = Signal(dict)

    def __init__(self) -> None:

        super().__init__()

        self._build_ui()

    def _build_ui(self) -> None:

        self.market = QComboBox()
        self.market.addItems(
            [
                "NSE",
                "BSE",
            ]
        )

        self.category = QComboBox()
        self.category.addItems(
            [
                "Today",
                "Intraday",
                "Swing",
                "Long Term",
                "F&O",
                "Penny",
            ]
        )

        self.price_band = QComboBox()
        self.price_band.addItems(
            [
                "All",
                "Below ₹100",
                "₹100 - ₹500",
                "₹500 - ₹1,000",
                "₹1,000 - ₹5,000",
                "Above ₹5,000",
                "Custom",
            ]
        )

        self.min_price = QLineEdit()
        self.min_price.setPlaceholderText("Min")

        self.max_price = QLineEdit()
        self.max_price.setPlaceholderText("Max")

        self.capital = QComboBox()
        self.capital.addItems(
            [
                "₹10,000",
                "₹25,000",
                "₹50,000",
                "₹1,00,000",
                "₹5,00,000",
                "Custom",
            ]
        )

        self.sort_by = QComboBox()
        self.sort_by.addItems(
            [
                "Score",
                "Confidence",
                "Probability",
                "Price",
                "Volume",
            ]
        )

        self.top = QComboBox()
        self.top.addItems(
            [
                "10",
                "20",
                "50",
            ]
        )

        self.scan_button = QPushButton("SCAN")
        self.scan_button.clicked.connect(
            self._emit_scan_request,
        )

        form = QFormLayout()

        form.addRow(
            QLabel("Market"),
            self.market,
        )

        form.addRow(
            QLabel("Category"),
            self.category,
        )

        form.addRow(
            QLabel("Price Band"),
            self.price_band,
        )

        form.addRow(
            QLabel("Min Price"),
            self.min_price,
        )

        form.addRow(
            QLabel("Max Price"),
            self.max_price,
        )

        form.addRow(
            QLabel("Capital"),
            self.capital,
        )

        form.addRow(
            QLabel("Sort By"),
            self.sort_by,
        )

        form.addRow(
            QLabel("Top"),
            self.top,
        )

        group = QGroupBox("Filters")
        group.setLayout(form)

        layout = QHBoxLayout()

        layout.addWidget(group)

        layout.addStretch()

        layout.addWidget(self.scan_button)

        self.setLayout(layout)

    def _emit_scan_request(self) -> None:

        self.scan_requested.emit(
            {
                "market": self.market.currentText(),
                "category": self.category.currentText(),
                "price_band": self.price_band.currentText(),
                "min_price": self.min_price.text(),
                "max_price": self.max_price.text(),
                "capital": self.capital.currentText(),
                "sort_by": self.sort_by.currentText(),
                "top": int(self.top.currentText()),
            }
        )