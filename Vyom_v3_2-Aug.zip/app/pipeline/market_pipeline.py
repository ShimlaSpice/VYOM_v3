"""
Complete Market Pipeline.

UI
 ↓
Scanner
 ↓
Recommendation Pipeline
 ↓
Top10
"""

from concurrent.futures import ThreadPoolExecutor

from app.market.provider_manager import ProviderManager
from app.pipeline.recommendation_pipeline import RecommendationPipeline
from app.scanner.scanner import ScannerEngine
from app.top10 import Top10Engine


class MarketPipeline:

    def __init__(self):

        self.provider = ProviderManager()

        self.provider.connect()

        self.scanner = ScannerEngine(

            self.provider,

        )

        self.pipeline = RecommendationPipeline()

        self.top10 = Top10Engine()

    def run(

        self,

        filters: dict | None = None,

    ):

        if filters is None:

            filters = {

                "universe": "NIFTY50",

                "top": 10,

            }

        scan_result = self.scanner.scan(

            filters=filters,

        )

        candidates = scan_result.candidates

        if not candidates:

            return []

        symbols = [

            c.symbol

            for c in candidates

        ]

        self.provider.prefetch(

            symbols=symbols,

            period="6mo",

            interval="1d",

        )

        def build_recommendation(

            candidate,

        ):

            candles = self.provider.get_candles(

                symbol=candidate.symbol,

                interval="1d",

                limit=100,

            )

            if len(candles) < 50:

                return None

            fundamentals = self.provider.get_fundamentals(

                candidate.symbol,

            ) or {}

            news = self.provider.get_news(

                candidate.symbol,

            ) or {

                "sentiment": "NEUTRAL",

                "confidence": 0.50,

                "headlines": [],

            }

            return self.pipeline.build(

                candidate=candidate,

                candles=candles,

                fundamentals=fundamentals,

                news=news,

                sector=fundamentals.get(

                    "sector",

                    "Unknown",

                ),

            )


        workers = min(

            16,

            max(

                4,

                len(candidates) // 10,

            ),

        )

        with ThreadPoolExecutor(

            max_workers=workers,

        ) as executor:

            recommendations = [

                recommendation

                for recommendation in executor.map(

                    build_recommendation,

                    candidates,

                )

                if recommendation is not None

            ]

            recommendations.sort(

                key=lambda x: (

                    getattr(

                        x,

                        "confidence",

                        0,

                    ),

                    getattr(

                        x,

                        "probability",
                        0,

                    ),

                ),

                reverse=True,

            )

            return self.top10.generate(

                recommendations,

                limit=filters.get(

                    "top",

                    10,

                ),

            )